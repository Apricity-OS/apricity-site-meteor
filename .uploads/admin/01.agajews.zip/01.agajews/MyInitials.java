import kareltherobot.*;

/**
* @author
*   lab#:
*   date:
*/

class MyInitials implements Directions {
    public static void main(String[] args) {
        // Setup the world
        World.setSize(10, 20);
        //World.readWorld("labN.kwld"); // Change this!
        World.setVisible(true);

        // Create and A robot
        UrRobot karel = new UrRobot(2, 2, North, 100);
        for(int i=0; i<9; i++){
            karel.putBeeper();
            karel.move();
            karel.putBeeper();
            karel.move();
            karel.putBeeper();
            turnRobot(karel, "right");
            karel.move();
            //karel.putBeeper();
            turnRobot(karel, "left");
        }
        turnRobot(karel, "right");
        karel.putBeeper();
        karel.move();
        turnRobot(karel, "right");
        for(int i=0; i<9; i++){
            karel.putBeeper();
            karel.move();
            karel.putBeeper();
            karel.move();
            karel.putBeeper();
            turnRobot(karel, "left");
            karel.move();
            //karel.putBeeper();
            turnRobot(karel, "right");
        }
        turnRobot(karel, "right");
        for(int i=0; i<7; i++){
            karel.move();
        }
        turnRobot(karel, "right");
        for(int i=0; i<10; i++){
            karel.move();
        }
        for(int i=0; i<3; i++){
           karel.putBeeper();
           karel.move();
           karel.putBeeper();
           turnRobot(karel, "left");
           karel.move();
           karel.putBeeper();
           turnRobot(karel, "left");
           karel.move();
           karel.putBeeper();
           turnRobot(karel, "right");
           karel.move();
           turnRobot(karel, "right");
        }
        karel.putBeeper();
        karel.move();
        karel.putBeeper();
        turnRobot(karel, "left");
        karel.move();
        
        // Go Home
        for(int i=0; i<6; i++){
            karel.move();
        }
        turnRobot(karel, "left");
        for(int i=0; i<12; i++){
            karel.move();
        }
        turnRobot(karel, "around");
        
        // Create and Control G Robot
        UrRobot steve = new UrRobot(2, 24, North, 100);
        for(int i=0; i<19; i++){
            turnRobot(steve, "right");
            steve.putBeeper();
            steve.move();
            steve.putBeeper();
            turnRobot(steve, "around");
            steve.move();
            turnRobot(steve, "right");
            steve.move();
        }
        turnRobot(steve, "right");
        steve.move();
        steve.move();
        turnRobot(steve, "right");
        steve.move();
        turnRobot(steve, "left");
        for(int i=0; i<8; i++){
            turnRobot(steve, "right");
            steve.putBeeper();
            steve.move();
            steve.putBeeper();
            turnRobot(steve, "around");
            steve.move();
            turnRobot(steve, "right");
            steve.move();
        }
        turnRobot(steve, "right");
        for(int i=0; i<9; i++){
            steve.move();
        }
        turnRobot(steve, "right");
        steve.move();
        turnRobot(steve, "left");
        for(int i=0; i<8; i++){
            turnRobot(steve, "right");
            steve.putBeeper();
            steve.move();
            steve.putBeeper();
            turnRobot(steve, "around");
            steve.move();
            turnRobot(steve, "right");
            steve.move();
        }
        steve.move();
        turnRobot(steve, "right");
        for(int i=0; i<8; i++){
            turnRobot(steve, "right");
            steve.putBeeper();
            steve.move();
            steve.putBeeper();
            turnRobot(steve, "around");
            steve.move();
            turnRobot(steve, "right");
            steve.move();
        }
        turnRobot(steve, "right");
        for(int i=0; i<9; i++){
            steve.move();
        }
        turnRobot(steve, "right");
        steve.move();
        steve.move();
        for(int i=0; i<5; i++){
            turnRobot(steve, "right");
            steve.putBeeper();
            steve.move();
            steve.putBeeper();
            turnRobot(steve, "around");
            steve.move();
            turnRobot(steve, "right");
            steve.move();
        }
        
        // Go Home
        turnRobot(steve, "around");
        for(int i=0; i<31; i++){
            steve.move();
        }
        turnRobot(steve, "left");
        for(int i=0; i<9; i++){
            steve.move();
        }
        turnRobot(steve, "around");
    }
    public static void turnRobot(UrRobot robot, String direction){
        if(direction == "left"){
            robot.turnLeft();
        }
        else if(direction == "right"){
            for(int i=0; i<3; i++){
                robot.turnLeft();
            }
        }
        else if(direction == "around"){
            for(int i=0; i<2; i++){
                robot.turnLeft();
            }
        }
    }
}