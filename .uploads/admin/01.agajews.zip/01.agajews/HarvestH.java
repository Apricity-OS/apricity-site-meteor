import kareltherobot.*;

/**
* @author
*   lab#:
*   date:
*/

class HarvestH implements Directions {
    public static void main(String[] args) {
        // Setup the world
        World.setSize(10, 20);
        World.readWorld("SpecialH.kwld"); // Change this!
        World.setVisible(true);

        // Create and A robot
        UrRobot karel = new UrRobot(3, 3, South, 100);
        karel.pickBeeper();
        karel.move();
        turnRobot(karel, "right");
        karel.move();
        turnRobot(karel, "left");
        karel.pickBeeper();
        karel.move();
        turnRobot(karel, "left");
        karel.pickBeeper();
        karel.move();
        karel.move();
        turnRobot(karel, "left");
        karel.pickBeeper();
        for(int i=0; i<4; i++){
            karel.move();
            karel.pickBeeper();
        }
        turnRobot(karel, "left");
        karel.move();
        karel.move();
        turnRobot(karel, "left");
        karel.pickBeeper();
        for(int i=0; i<2; i++){
            karel.move();
            karel.pickBeeper();
        }
        World.showEfficiency();
    }
    public static void turnRobot(UrRobot robot, String direction){
        if(direction == "left"){
            robot.turnLeft();
        }
        else if(direction == "right"){
            for(int i=0; i<3; i++){
                robot.turnLeft();
            }
        }
        else if(direction == "around"){
            for(int i=0; i<2; i++){
                robot.turnLeft();
            }
        }
    }
}