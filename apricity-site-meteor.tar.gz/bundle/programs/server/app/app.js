var require = meteorInstall({"lib":{"accounts.js":["meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/accounts.js                                                                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var check;module.import('meteor/check',{"check":function(v){check=v}});                                             // 1
                                                                                                                    //
AccountsTemplates.configure({                                                                                       // 3
  // Behavior                                                                                                       //
  confirmPassword: true,                                                                                            // 5
  enablePasswordChange: true,                                                                                       // 6
  forbidClientAccountCreation: false,                                                                               // 7
  overrideLoginErrors: true,                                                                                        // 8
  sendVerificationEmail: true,                                                                                      // 9
  lowercaseUsername: true,                                                                                          // 10
  focusFirstInput: true,                                                                                            // 11
                                                                                                                    //
  // Appearance                                                                                                     //
  showAddRemoveServices: false,                                                                                     // 14
  showForgotPasswordLink: true,                                                                                     // 15
  showLabels: true,                                                                                                 // 16
  showPlaceholders: true,                                                                                           // 17
  showResendVerificationEmailLink: false,                                                                           // 18
                                                                                                                    //
  // Client-side Validation                                                                                         //
  continuousValidation: true,                                                                                       // 21
  negativeFeedback: true,                                                                                           // 22
  negativeValidation: true,                                                                                         // 23
  positiveValidation: true,                                                                                         // 24
  positiveFeedback: true,                                                                                           // 25
  showValidating: true,                                                                                             // 26
                                                                                                                    //
  // Privacy Policy and Terms of Use                                                                                //
  // privacyUrl: 'privacy',                                                                                         //
  // termsUrl: 'terms-of-use',                                                                                      //
                                                                                                                    //
  // Redirects                                                                                                      //
  homeRoutePath: '/',                                                                                               // 33
  redirectTimeout: 4000,                                                                                            // 34
                                                                                                                    //
  // Hooks                                                                                                          //
  onLogoutHook: function onLogoutHook() {                                                                           // 37
    FlowRouter.go('/login');                                                                                        // 38
  },                                                                                                                // 39
                                                                                                                    //
  postSignUpHook: function postSignUpHook(userId, info) {                                                           // 41
    Roles.addUsersToRoles(userId, 'newUser');                                                                       // 42
    Roles.addUsersToRoles(userId, 'user');                                                                          // 43
  },                                                                                                                // 44
  // onSubmitHook: mySubmitFunc,                                                                                    //
  // preSignUpHook: myPreSubmitFunc,                                                                                //
  // postSignUpHook: myPostSubmitFunc,                                                                              //
                                                                                                                    //
  // Texts                                                                                                          //
  texts: {                                                                                                          // 50
    button: {                                                                                                       // 51
      signUp: "Register Now!"                                                                                       // 52
    },                                                                                                              // 51
    title: {                                                                                                        // 54
      forgotPwd: "Recover Your Password"                                                                            // 55
    }                                                                                                               // 54
  },                                                                                                                // 50
                                                                                                                    //
  defaultLayout: 'auth',                                                                                            // 59
  defaultContentRegion: 'page',                                                                                     // 60
  defaultLayoutRegions: {}                                                                                          // 61
});                                                                                                                 // 3
                                                                                                                    //
AccountsTemplates.configureRoute('signIn', {                                                                        // 64
  name: 'login',                                                                                                    // 65
  path: '/login',                                                                                                   // 66
  redirect: '/'                                                                                                     // 67
});                                                                                                                 // 64
                                                                                                                    //
AccountsTemplates.configureRoute('signUp', {                                                                        // 70
  name: 'signup',                                                                                                   // 71
  path: '/signup'                                                                                                   // 72
});                                                                                                                 // 70
                                                                                                                    //
AccountsTemplates.configureRoute('forgotPwd', {                                                                     // 75
  name: 'forgotPwd',                                                                                                // 76
  path: '/forgot-password'                                                                                          // 77
});                                                                                                                 // 75
                                                                                                                    //
AccountsTemplates.configureRoute('resetPwd', {                                                                      // 80
  name: 'resetPwd',                                                                                                 // 81
  path: '/reset-password'                                                                                           // 82
});                                                                                                                 // 80
                                                                                                                    //
AccountsTemplates.configureRoute('verifyEmail', {                                                                   // 85
  name: 'verifyEmail',                                                                                              // 86
  path: '/verify-email'                                                                                             // 87
});                                                                                                                 // 85
                                                                                                                    //
AccountsTemplates.configureRoute('enrollAccount', {                                                                 // 90
  name: 'enrollAccount',                                                                                            // 91
  path: '/enroll-account'                                                                                           // 92
});                                                                                                                 // 90
                                                                                                                    //
Meteor.methods({                                                                                                    // 95
  'users.removeFromNew': function usersRemoveFromNew() {                                                            // 96
    Roles.removeUsersFromRoles(Meteor.userId(), 'newUser');                                                         // 97
  },                                                                                                                // 98
  'users.makeUser': function usersMakeUser(userId) {                                                                // 99
    check(userId, String);                                                                                          // 100
    if (!this.userId || !Roles.userIsInRole(this.userId, 'admin')) {                                                // 101
      throw new Meteor.Error('not-authorized');                                                                     // 102
    }                                                                                                               // 103
    if (userId === Meteor.userId() || Meteor.users.findOne({ _id: userId }).username === 'admin') {                 // 104
      throw new Meteor.Error('not-allowed');                                                                        // 105
    }                                                                                                               // 106
    Roles.removeUsersFromRoles(userId, 'admin');                                                                    // 107
    Roles.removeUsersFromRoles(userId, 'moderator');                                                                // 108
    Roles.addUsersToRoles(userId, 'user');                                                                          // 109
  },                                                                                                                // 110
  'users.makeMod': function usersMakeMod(userId) {                                                                  // 111
    check(userId, String);                                                                                          // 112
    if (!this.userId || !Roles.userIsInRole(this.userId, 'admin')) {                                                // 113
      throw new Meteor.Error('not-authorized');                                                                     // 114
    }                                                                                                               // 115
    if (userId === Meteor.userId() || Meteor.users.findOne({ _id: userId }).username === 'admin') {                 // 116
      throw new Meteor.Error('not-allowed');                                                                        // 117
    }                                                                                                               // 118
    Roles.removeUsersFromRoles(userId, 'admin');                                                                    // 119
    Roles.removeUsersFromRoles(userId, 'user');                                                                     // 120
    Roles.addUsersToRoles(userId, 'moderator');                                                                     // 121
  },                                                                                                                // 122
  'users.makeAdmin': function usersMakeAdmin(userId) {                                                              // 123
    check(userId, String);                                                                                          // 124
    if (!this.userId || !Roles.userIsInRole(this.userId, 'admin')) {                                                // 125
      throw new Meteor.Error('not-authorized');                                                                     // 126
    }                                                                                                               // 127
    Roles.removeUsersFromRoles(userId, 'moderator');                                                                // 128
    Roles.removeUsersFromRoles(userId, 'user');                                                                     // 129
    Roles.addUsersToRoles(userId, 'admin');                                                                         // 130
  }                                                                                                                 // 131
});                                                                                                                 // 95
                                                                                                                    //
var pwd = AccountsTemplates.removeField('password');                                                                // 134
AccountsTemplates.removeField('email');                                                                             // 135
AccountsTemplates.addFields([{                                                                                      // 136
  _id: "username",                                                                                                  // 138
  type: "text",                                                                                                     // 139
  displayName: "username",                                                                                          // 140
  required: true,                                                                                                   // 141
  minLength: 5                                                                                                      // 142
}, {                                                                                                                // 137
  _id: 'email',                                                                                                     // 145
  type: 'email',                                                                                                    // 146
  required: true,                                                                                                   // 147
  displayName: "email",                                                                                             // 148
  re: /.+@(.+){2,}\.(.+){2,}/,                                                                                      // 149
  errStr: 'Invalid email'                                                                                           // 150
}, pwd]);                                                                                                           // 144
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"routes.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/routes.js                                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var exposedRoutes = FlowRouter.group({});                                                                           // 1
                                                                                                                    //
exposedRoutes.route('/download', {                                                                                  // 3
    action: function action() {                                                                                     // 4
        BlazeLayout.render('app', {                                                                                 // 5
            page: 'downloadPage'                                                                                    // 6
        });                                                                                                         // 5
    },                                                                                                              // 8
    name: 'download'                                                                                                // 9
});                                                                                                                 // 3
                                                                                                                    //
exposedRoutes.route('/forum', {                                                                                     // 12
    action: function action() {                                                                                     // 13
        BlazeLayout.render('app', {                                                                                 // 14
            page: 'forumPage'                                                                                       // 15
        });                                                                                                         // 14
    },                                                                                                              // 17
    name: 'forum'                                                                                                   // 18
});                                                                                                                 // 12
                                                                                                                    //
exposedRoutes.route('/forum/category/:_id', {                                                                       // 21
    action: function action() {                                                                                     // 22
        BlazeLayout.render('app', {                                                                                 // 23
            page: 'forumCategoryPage'                                                                               // 24
        });                                                                                                         // 23
    },                                                                                                              // 26
    name: 'forumCategory'                                                                                           // 27
});                                                                                                                 // 21
                                                                                                                    //
exposedRoutes.route('/forum/discussion/:_id', {                                                                     // 30
    action: function action() {                                                                                     // 31
        BlazeLayout.render('app', {                                                                                 // 32
            page: 'forumDiscussionPage'                                                                             // 33
        });                                                                                                         // 32
    },                                                                                                              // 35
    name: 'forumDiscussion'                                                                                         // 36
});                                                                                                                 // 30
                                                                                                                    //
exposedRoutes.route('/blog', {                                                                                      // 39
    action: function action() {                                                                                     // 40
        BlazeLayout.render('app', {                                                                                 // 41
            page: 'blogPage'                                                                                        // 42
        });                                                                                                         // 41
    },                                                                                                              // 44
    name: 'blog'                                                                                                    // 45
});                                                                                                                 // 39
                                                                                                                    //
exposedRoutes.route('/blog/post/:cleanName', {                                                                      // 48
    action: function action() {                                                                                     // 49
        BlazeLayout.render('app', {                                                                                 // 50
            page: 'blogPostPage'                                                                                    // 51
        });                                                                                                         // 50
    },                                                                                                              // 53
    name: 'blogPost'                                                                                                // 54
});                                                                                                                 // 48
                                                                                                                    //
exposedRoutes.route('/docs', {                                                                                      // 57
    action: function action() {                                                                                     // 58
        BlazeLayout.render('app', {                                                                                 // 59
            page: 'docsPage'                                                                                        // 60
        });                                                                                                         // 59
    },                                                                                                              // 62
    name: 'docs'                                                                                                    // 63
});                                                                                                                 // 57
                                                                                                                    //
exposedRoutes.route('/blog/docs/:cleanName', {                                                                      // 66
    action: function action() {                                                                                     // 67
        BlazeLayout.render('app', {                                                                                 // 68
            page: 'docsEntryPage'                                                                                   // 69
        });                                                                                                         // 68
    },                                                                                                              // 71
    name: 'docsEntry'                                                                                               // 72
});                                                                                                                 // 66
                                                                                                                    //
exposedRoutes.route('/docs/entry/:cleanName', {                                                                     // 75
    action: function action() {                                                                                     // 76
        BlazeLayout.render('app', {                                                                                 // 77
            page: 'docsEntryPage'                                                                                   // 78
        });                                                                                                         // 77
    },                                                                                                              // 80
    name: 'docsEntry'                                                                                               // 81
});                                                                                                                 // 75
                                                                                                                    //
function redirectIfLoggedIn(ctx, redirect) {                                                                        // 84
    if (Meteor.userId()) {                                                                                          // 85
        FlowRouter.go('dash');                                                                                      // 86
    }                                                                                                               // 87
}                                                                                                                   // 88
                                                                                                                    //
var marketing = FlowRouter.group({                                                                                  // 90
    name: 'marketing',                                                                                              // 91
    triggersEnter: [redirectIfLoggedIn]                                                                             // 92
});                                                                                                                 // 90
                                                                                                                    //
marketing.route('/', {                                                                                              // 95
    action: function action() {                                                                                     // 96
        BlazeLayout.render('app', {                                                                                 // 97
            page: 'homePage'                                                                                        // 98
        });                                                                                                         // 97
    },                                                                                                              // 100
    name: 'home'                                                                                                    // 101
});                                                                                                                 // 95
                                                                                                                    //
marketing.route('/features', {                                                                                      // 104
    action: function action() {                                                                                     // 105
        BlazeLayout.render('app', {                                                                                 // 106
            page: 'featuresPage'                                                                                    // 107
        });                                                                                                         // 106
    },                                                                                                              // 109
    name: 'features'                                                                                                // 110
});                                                                                                                 // 104
                                                                                                                    //
function redirectIfNotLoggedIn(ctx, redirect) {                                                                     // 113
    if (!Meteor.userId()) {                                                                                         // 114
        FlowRouter.go('signup');                                                                                    // 115
    }                                                                                                               // 116
}                                                                                                                   // 117
                                                                                                                    //
var authenticatedRoutes = FlowRouter.group({                                                                        // 119
    name: 'authenticatedRoutes',                                                                                    // 120
    triggersEnter: [redirectIfNotLoggedIn]                                                                          // 121
});                                                                                                                 // 119
                                                                                                                    //
authenticatedRoutes.route('/dash', {                                                                                // 124
    action: function action() {                                                                                     // 125
        BlazeLayout.render('app', {                                                                                 // 126
            page: 'dashPage'                                                                                        // 127
        });                                                                                                         // 126
    },                                                                                                              // 129
    name: 'dash'                                                                                                    // 130
});                                                                                                                 // 124
                                                                                                                    //
authenticatedRoutes.route('/my-configs', {                                                                          // 133
    action: function action() {                                                                                     // 134
        BlazeLayout.render('app', {                                                                                 // 135
            page: 'myConfigsPage'                                                                                   // 136
        });                                                                                                         // 135
    },                                                                                                              // 138
    name: 'myConfigs'                                                                                               // 139
});                                                                                                                 // 133
                                                                                                                    //
authenticatedRoutes.route('/user/:username', {                                                                      // 142
    action: function action() {                                                                                     // 143
        BlazeLayout.render('app', {                                                                                 // 144
            page: 'userConfigsPage'                                                                                 // 145
        });                                                                                                         // 144
    },                                                                                                              // 147
    name: 'userConfigs'                                                                                             // 148
});                                                                                                                 // 142
                                                                                                                    //
authenticatedRoutes.route('/user/:username/config/:configName', {                                                   // 151
    action: function action() {                                                                                     // 152
        BlazeLayout.render('app', {                                                                                 // 153
            page: 'specificConfigPage'                                                                              // 154
        });                                                                                                         // 153
    },                                                                                                              // 156
    name: 'specificConfig'                                                                                          // 157
});                                                                                                                 // 151
                                                                                                                    //
authenticatedRoutes.route('/user/:username/config/:configName/iso', {                                               // 160
    action: function action() {                                                                                     // 161
        BlazeLayout.render('app', {                                                                                 // 162
            page: 'isoPage'                                                                                         // 163
        });                                                                                                         // 162
    },                                                                                                              // 165
    name: 'iso'                                                                                                     // 166
});                                                                                                                 // 160
                                                                                                                    //
authenticatedRoutes.route('/user/:username/config/:configName/edit', {                                              // 169
    action: function action() {                                                                                     // 170
        BlazeLayout.render('app', {                                                                                 // 171
            page: 'createPage'                                                                                      // 172
        });                                                                                                         // 171
    },                                                                                                              // 174
    name: 'specificConfigEdit'                                                                                      // 175
});                                                                                                                 // 169
                                                                                                                    //
authenticatedRoutes.route('/user/:username/config/:configName/clone', {                                             // 178
    action: function action() {                                                                                     // 179
        BlazeLayout.render('app', {                                                                                 // 180
            page: 'createPage'                                                                                      // 181
        });                                                                                                         // 180
    },                                                                                                              // 183
    name: 'specificConfigClone'                                                                                     // 184
});                                                                                                                 // 178
                                                                                                                    //
authenticatedRoutes.route('/create/', {                                                                             // 187
    action: function action() {                                                                                     // 188
        BlazeLayout.render('app', {                                                                                 // 189
            page: 'createPage'                                                                                      // 190
        });                                                                                                         // 189
    },                                                                                                              // 192
    name: 'create'                                                                                                  // 193
});                                                                                                                 // 187
                                                                                                                    //
authenticatedRoutes.route('/account', {                                                                             // 196
    action: function action() {                                                                                     // 197
        BlazeLayout.render('app', {                                                                                 // 198
            page: 'accountPage'                                                                                     // 199
        });                                                                                                         // 198
    },                                                                                                              // 201
    name: 'account'                                                                                                 // 202
});                                                                                                                 // 196
                                                                                                                    //
authenticatedRoutes.route('/signout', {                                                                             // 205
    action: function action() {                                                                                     // 206
        AccountsTemplates.logout();                                                                                 // 207
    },                                                                                                              // 208
    name: 'signout'                                                                                                 // 209
});                                                                                                                 // 205
                                                                                                                    //
authenticatedRoutes.route('/forum/add-discussion', {                                                                // 212
    action: function action() {                                                                                     // 213
        BlazeLayout.render('app', {                                                                                 // 214
            page: 'addDiscussionPage'                                                                               // 215
        });                                                                                                         // 214
    },                                                                                                              // 217
    name: 'addDiscussion'                                                                                           // 218
});                                                                                                                 // 212
                                                                                                                    //
authenticatedRoutes.route('/docs/add-entry', {                                                                      // 221
    action: function action() {                                                                                     // 222
        BlazeLayout.render('app', {                                                                                 // 223
            page: 'addDocsEntryPage'                                                                                // 224
        });                                                                                                         // 223
    },                                                                                                              // 226
    name: 'addDocsEntry'                                                                                            // 227
});                                                                                                                 // 221
                                                                                                                    //
function redirectIfNotAdmin() {                                                                                     // 230
    if (!Roles.userIsInRole(Meteor.userId(), 'admin')) {                                                            // 231
        FlowRouter.go('dash');                                                                                      // 232
    }                                                                                                               // 233
}                                                                                                                   // 234
                                                                                                                    //
var adminRoutes = FlowRouter.group({                                                                                // 236
    name: 'admin',                                                                                                  // 237
    triggersEnter: [redirectIfNotLoggedIn, redirectIfNotAdmin]                                                      // 238
});                                                                                                                 // 236
                                                                                                                    //
adminRoutes.route('/admin', {                                                                                       // 243
    action: function action() {                                                                                     // 244
        FlowRouter.go('adminUsers');                                                                                // 245
    },                                                                                                              // 246
    name: 'admin'                                                                                                   // 247
});                                                                                                                 // 243
                                                                                                                    //
adminRoutes.route('/admin/users', {                                                                                 // 250
    action: function action() {                                                                                     // 251
        BlazeLayout.render('app', {                                                                                 // 252
            page: 'adminUserPage'                                                                                   // 253
        });                                                                                                         // 252
    },                                                                                                              // 255
    name: 'adminUsers'                                                                                              // 256
});                                                                                                                 // 250
                                                                                                                    //
adminRoutes.route('/admin/content', {                                                                               // 259
    action: function action() {                                                                                     // 260
        BlazeLayout.render('app', {                                                                                 // 261
            page: 'adminContentPage'                                                                                // 262
        });                                                                                                         // 261
    },                                                                                                              // 264
    name: 'adminContent'                                                                                            // 265
});                                                                                                                 // 259
                                                                                                                    //
adminRoutes.route('/admin/downloads', {                                                                             // 268
    action: function action() {                                                                                     // 269
        BlazeLayout.render('app', {                                                                                 // 270
            page: 'adminDownloadsPage'                                                                              // 271
        });                                                                                                         // 270
    },                                                                                                              // 273
    name: 'adminDownloads'                                                                                          // 274
});                                                                                                                 // 268
                                                                                                                    //
FlowRouter.notFound = {                                                                                             // 277
    action: function action() {                                                                                     // 278
        BlazeLayout.render('app', {                                                                                 // 279
            page: 'pageNotFound'                                                                                    // 280
        });                                                                                                         // 279
    }                                                                                                               // 282
};                                                                                                                  // 277
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"runonce.js":["meteor/mongo","meteor/check","meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/runonce.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({runOnce:function(){return runOnce}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                    // 2
                                                                                                                    // 3
                                                                                                                    //
var RunOnce = new Mongo.Collection('runonce');                                                                      // 5
                                                                                                                    //
function runOnce(func, name) {                                                                                      // 7
  if (!RunOnce.findOne({ name: name })) {                                                                           // 8
    func();                                                                                                         // 9
    RunOnce.insert({ name: name });                                                                                 // 10
  }                                                                                                                 // 11
}                                                                                                                   // 12
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"underscore.js":["babel-runtime/helpers/typeof",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// lib/underscore.js                                                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});                       //
/**                                                                                                                 //
 * Simple underscore function to create secure inmutable (recursive deep copy) JavaScript Objects                   //
 * @param {Object/Array} obj Target Object. Required                                                                //
 * @param {Number} depth Depth level. Defaults to 1                                                                 //
 * @return {Object/Array) Super inmutable new Object                                                                //
 * @method deepClone                                                                                                //
 */                                                                                                                 //
_.deepClone = function deepClone(obj, depth) {                                                                      // 8
  var clone, key;                                                                                                   // 9
  depth = depth || 1;                                                                                               // 10
  if ((typeof obj === 'undefined' ? 'undefined' : _typeof(obj)) !== 'object' || obj === null) {                     // 11
    return obj;                                                                                                     // 11
  }                                                                                                                 // 11
  if (_.isString(obj)) {                                                                                            // 12
    return obj.splice();                                                                                            // 12
  }                                                                                                                 // 12
  if (_.isDate(obj)) {                                                                                              // 13
    return new Date(obj.getTime());                                                                                 // 13
  }                                                                                                                 // 13
  if (_.isFunction(obj.clone)) {                                                                                    // 14
    return obj.clone();                                                                                             // 14
  }                                                                                                                 // 14
  clone = _.isArray(obj) ? obj.slice() : _.extend({}, obj);                                                         // 15
  if (depth !== undefined && depth > 0) {                                                                           // 16
    for (key in clone) {                                                                                            // 17
      clone[key] = deepClone(clone[key], depth - 1);                                                                // 18
    }                                                                                                               // 19
  }                                                                                                                 // 20
  return clone;                                                                                                     // 21
};                                                                                                                  // 22
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"imports":{"api":{"builds.js":["meteor/mongo","meteor/check","meteor/meteor","./configs.js","tomlify",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/builds.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Builds:function(){return Builds},configToToml:function(){return configToToml}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Configs;module.import('./configs.js',{"Configs":function(v){Configs=v}});var tomlify;module.import('tomlify',{"default":function(v){tomlify=v}});
                                                                                                                    // 2
                                                                                                                    // 3
                                                                                                                    //
                                                                                                                    // 5
                                                                                                                    //
                                                                                                                    // 7
                                                                                                                    //
var Builds = new Mongo.Collection('builds');                                                                        // 9
                                                                                                                    //
function configToToml(config) {                                                                                     // 11
  // Turn arrays into dicts                                                                                         //
  var outConfig = _.deepClone(config, 3);                                                                           // 13
  outConfig.pacman.packages = { gen: outConfig.pacman.packages };                                                   // 14
  outConfig.systemd.services = { gen: outConfig.systemd.services };                                                 // 15
  if (outConfig.gnome) {                                                                                            // 16
    outConfig.gnome.extensions = { gen: outConfig.gnome.extensions };                                               // 17
    outConfig.gnome.favorite_apps = { gen: outConfig.gnome.favorite_apps };                                         // 18
  }                                                                                                                 // 19
  if (outConfig.cinnamon) {                                                                                         // 20
    outConfig.cinnamon.favorite_apps = { gen: outConfig.cinnamon.favorite_apps };                                   // 21
  }                                                                                                                 // 22
  outConfig.vim.plugins = { gen: outConfig.vim.plugins };                                                           // 23
  outConfig.vim.vimrc = { gen: outConfig.vim.vimrc };                                                               // 24
  outConfig.zsh.zshrc = { gen: outConfig.zsh.zshrc };                                                               // 25
  outConfig.code.root = { gen: outConfig.code.root };                                                               // 26
  outConfig.code.user = { gen: outConfig.code.user };                                                               // 27
                                                                                                                    //
  var toml = 'inherits = "base.toml"\n' + tomlify(outConfig);                                                       // 29
  return toml;                                                                                                      // 30
}                                                                                                                   // 31
                                                                                                                    //
// UPDATE THIS                                                                                                      //
var buildServerUrl = 'http://10.136.15.8:8000';                                                                     // 34
// let buildServerUrl = 'http://159.203.176.252:8000';                                                              //
var staticServerUrl = 'https://static.apricityos.com';                                                              // 36
                                                                                                                    //
var MAX_BUILDS = 30;                                                                                                // 38
                                                                                                                    //
function startQueuedBuild() {                                                                                       // 40
  var build = Builds.findOne({ queued: true }, { sort: { queuedTime: 1 } });                                        // 41
  var toml = configToToml(build.config);                                                                            // 42
                                                                                                                    //
  HTTP.del(buildServerUrl + '/build');                                                                              // 44
  HTTP.put(buildServerUrl + '/build', {                                                                             // 45
    params: {                                                                                                       // 46
      'oname': build.name,                                                                                          // 47
      'username': build.configUsername,                                                                             // 48
      'config': toml,                                                                                               // 49
      'num': build.buildNum                                                                                         // 50
    }                                                                                                               // 46
  }, function (error, response) {                                                                                   // 45
    if (error) {                                                                                                    // 53
      // console.log(error);                                                                                        //
    } else {                                                                                                        // 55
        Builds.update({ _id: build._id }, { $set: { running: true, queued: false } });                              // 56
        // console.log(response);                                                                                   //
      }                                                                                                             // 58
  });                                                                                                               // 59
}                                                                                                                   // 60
                                                                                                                    //
function deleteBuild(username, isoName) {                                                                           // 62
  HTTP.del(buildServerUrl + '/build/' + username + '/' + isoName);                                                  // 63
}                                                                                                                   // 64
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 66
  Meteor.publish('builds', function () {                                                                            // 67
    return Builds.find();                                                                                           // 68
  });                                                                                                               // 69
                                                                                                                    //
  // Reset build queue                                                                                              //
  Meteor.setInterval(function checkBuildQueue() {                                                                   // 72
    if (!Builds.findOne({ running: true })) {                                                                       // 73
      if (Builds.find({ queued: true }).fetch().length) {                                                           // 74
        // ENABLE                                                                                                   //
        startQueuedBuild();                                                                                         // 76
      }                                                                                                             // 77
    } else {                                                                                                        // 78
      // a build is running                                                                                         //
      HTTP.get(buildServerUrl + '/build', {}, function (error, response) {                                          // 79
        if (error) {                                                                                                // 80
          // console.log(error);                                                                                    //
        } else {                                                                                                    // 82
            var runningBuild = Builds.findOne({ running: true });                                                   // 83
            // console.log(response);                                                                               //
            var data = response.data;                                                                               // 85
            if (data.status === 'success') {                                                                        // 86
              Builds.update({ running: true }, { $set: {                                                            // 87
                  running: false,                                                                                   // 88
                  queued: false,                                                                                    // 89
                  completed: true,                                                                                  // 90
                  failed: false,                                                                                    // 91
                  download: staticServerUrl + '/freezedry-build/' + runningBuild.configUsername + '/apricity_os-' + runningBuild.name + '-' + runningBuild.buildNum + '.iso',
                  log: staticServerUrl + '/freezedry-build/' + runningBuild.configUsername + '/apricity_os-' + runningBuild.name + '-' + runningBuild.buildNum + '.log'
                } });                                                                                               // 87
            } else if (data.status === 'failure') {                                                                 // 99
              Builds.update({ running: true }, { $set: {                                                            // 100
                  running: false,                                                                                   // 101
                  queued: false,                                                                                    // 102
                  completed: false,                                                                                 // 103
                  failed: true,                                                                                     // 104
                  log: staticServerUrl + '/freezedry-build/' + runningBuild.configUsername + '/apricity_os-' + runningBuild.name + '-' + runningBuild.buildNum + '.log'
                } });                                                                                               // 100
            } else if (data.status === 'not completed') {                                                           // 109
              // console.log('Current build not completed');                                                        //
            }                                                                                                       // 111
          }                                                                                                         // 112
      });                                                                                                           // 113
    }                                                                                                               // 114
  }, 30000); // run every 30 seconds                                                                                // 115
}                                                                                                                   // 116
                                                                                                                    //
Meteor.methods({                                                                                                    // 118
  'builds.add': function buildsAdd(configId, configUsername) {                                                      // 119
    check(configId, String);                                                                                        // 120
    check(configUsername, String);                                                                                  // 121
                                                                                                                    //
    if (!this.userId) {                                                                                             // 123
      throw new Meteor.Error('not-authorized');                                                                     // 124
    }                                                                                                               // 125
                                                                                                                    //
    var config = Configs.findOne({                                                                                  // 127
      _id: configId,                                                                                                // 128
      username: configUsername                                                                                      // 129
    });                                                                                                             // 127
                                                                                                                    //
    if (!config) {                                                                                                  // 132
      throw new Meteor.Error('config-not-found');                                                                   // 133
    }                                                                                                               // 134
                                                                                                                    //
    var buildNum = Builds.find({                                                                                    // 136
      configUsername: config.username,                                                                              // 137
      name: config.name                                                                                             // 138
    }).fetch().length + 1;                                                                                          // 136
    var latest = Builds.findOne({                                                                                   // 140
      configUsername: config.username,                                                                              // 141
      name: config.name                                                                                             // 142
    }, { sort: { buildNum: -1 } });                                                                                 // 140
    if (latest) {                                                                                                   // 144
      Builds.update({ _id: latest._id }, { $set: { latest: false } });                                              // 145
    }                                                                                                               // 146
    // has download link, not protected                                                                             //
    if (Builds.find({ download: { $ne: undefined },                                                                 // 148
      'protected': false }).fetch().length > MAX_BUILDS) {                                                          // 149
      // delete oldest build download                                                                               //
      var oldest = Builds.findOne({ download: { $ne: undefined },                                                   // 151
        'protected': { $ne: true } }, { sort: { queuedTime: 1 } });                                                 // 152
      // Builds.remove({_id: oldest._id});                                                                          //
      Builds.update({ _id: oldest._id }, { $set: { download: undefined } });                                        // 154
      deleteBuild(oldest.configUsername, oldest.name + '-' + oldest.buildNum);                                      // 155
    }                                                                                                               // 156
                                                                                                                    //
    // console.log(Builds.find({                                                                                    //
    //   configUsername: configUsername,                                                                            //
    //   name: config.name                                                                                          //
    // }).fetch());                                                                                                 //
                                                                                                                    //
    if (Builds.find({                                                                                               // 163
      configUsername: configUsername,                                                                               // 164
      name: config.name,                                                                                            // 165
      $or: [{ queued: true }, { running: true }]                                                                    // 166
    }).fetch().length !== 0) {                                                                                      // 163
      throw new Meteor.Error('not-allowed');                                                                        // 168
    }                                                                                                               // 169
                                                                                                                    //
    var protected = false;                                                                                          // 171
    if (Meteor.users.find({ _id: this.userId }).username === 'admin') {                                             // 172
      protected = true;                                                                                             // 173
    }                                                                                                               // 174
                                                                                                                    //
    Builds.insert({                                                                                                 // 176
      config: config.config,                                                                                        // 177
      name: config.name,                                                                                            // 178
      configId: configId,                                                                                           // 179
      configUsername: configUsername,                                                                               // 180
      username: Meteor.user().username,                                                                             // 181
      initiator: this.userId,                                                                                       // 182
      configOwner: config.owner,                                                                                    // 183
      queuedTime: new Date(),                                                                                       // 184
      buildNum: buildNum,                                                                                           // 185
      latest: true,                                                                                                 // 186
      running: false,                                                                                               // 187
      queued: true,                                                                                                 // 188
      'protected': protected                                                                                        // 189
    });                                                                                                             // 176
  },                                                                                                                // 191
  'builds.remove': function buildsRemove(buildId) {                                                                 // 193
    check(buildId, String);                                                                                         // 194
                                                                                                                    //
    if (!this.userId) {                                                                                             // 196
      throw new Meteor.Error('not-authorized');                                                                     // 197
    }                                                                                                               // 198
                                                                                                                    //
    if (!Builds.findOne({ _id: buildId })) {                                                                        // 200
      throw new Meteor.Error('not-authorized');                                                                     // 201
    }                                                                                                               // 202
                                                                                                                    //
    if (!Builds.findOne({ _id: buildId }).queued) {                                                                 // 204
      throw new Meteor.Error('not-allowed');                                                                        // 205
    }                                                                                                               // 206
                                                                                                                    //
    var build = Builds.findOne({ _id: buildId });                                                                   // 208
                                                                                                                    //
    if (build.username !== Meteor.user().username && build.configOwner !== this.userId && !Roles.userIsInRole(this.userId, 'admin')) {
      throw new Meteor.error('not-authorized');                                                                     // 213
    }                                                                                                               // 214
                                                                                                                    //
    Builds.remove({ _id: buildId });                                                                                // 216
  }                                                                                                                 // 217
});                                                                                                                 // 118
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"categories.js":["meteor/mongo",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/categories.js                                                                                        //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Categories:function(){return Categories},ParentCategories:function(){return ParentCategories}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                                                    //
var Categories = new Mongo.Collection('categories');                                                                // 3
var ParentCategories = new Mongo.Collection('parent_categories');                                                   // 4
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 6
  Meteor.publish('categories', function () {                                                                        // 7
    return Categories.find();                                                                                       // 8
  });                                                                                                               // 9
                                                                                                                    //
  Meteor.publish('parentCategories', function () {                                                                  // 11
    return ParentCategories.find();                                                                                 // 12
  });                                                                                                               // 13
}                                                                                                                   // 14
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"comments.js":["meteor/mongo","./discussions.js","meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/comments.js                                                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Comments:function(){return Comments}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Discussions;module.import('./discussions.js',{"Discussions":function(v){Discussions=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                    // 2
                                                                                                                    // 3
                                                                                                                    //
var Comments = new Mongo.Collection('comments');                                                                    // 5
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 7
  Meteor.publish('comments', function () {                                                                          // 8
    return Comments.find();                                                                                         // 9
  });                                                                                                               // 10
}                                                                                                                   // 11
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 13
  (function () {                                                                                                    // 13
    var notifyDiscussionContributors = function notifyDiscussionContributors(discussionId, editorUsername) {        // 14
      var discussionName = Discussions.findOne({ _id: discussionId }).name;                                         // 15
      _.each(_.uniq(_.union(_.map(Comments.find({ discussion: discussionId }).fetch(), function (c) {               // 16
        return c.username;                                                                                          // 17
      }), [Discussions.findOne({ _id: discussionId }).username, 'admin'])), function (username) {                   // 17
        if (username !== Meteor.user().username) {                                                                  // 21
          Email.send({                                                                                              // 22
            to: Meteor.users.findOne({ username: username }).emails[0].address,                                     // 23
            from: "postmaster@apricityos.com",                                                                      // 24
            subject: "Apricity OS Forum: New Comment On " + discussionName,                                         // 25
            text: editorUsername + " commented on a discussion you participated in.\n\n" + "Follow the link below to check it out:" + "\nhttp://apricityos.com/forum/discussion/" + discussionId + "\n\nHave a great day!"
          });                                                                                                       // 22
        }                                                                                                           // 30
      });                                                                                                           // 31
    };                                                                                                              // 32
                                                                                                                    //
    Meteor.methods({                                                                                                // 34
      'comments.add': function commentsAdd(discussionId, commentText) {                                             // 35
        check(discussionId, String);                                                                                // 36
        check(commentText, String);                                                                                 // 37
        if (!this.userId) {                                                                                         // 38
          throw new Meteor.Error('not-authorized');                                                                 // 39
        }                                                                                                           // 40
                                                                                                                    //
        if (!Discussions.findOne({ _id: discussionId })) {                                                          // 42
          throw new Meteor.Error('discussion-not-found');                                                           // 43
        }                                                                                                           // 44
                                                                                                                    //
        Comments.insert({                                                                                           // 46
          username: Meteor.user().username,                                                                         // 47
          body: commentText,                                                                                        // 48
          createdAt: new Date(),                                                                                    // 49
          discussion: discussionId                                                                                  // 50
        });                                                                                                         // 46
                                                                                                                    //
        notifyDiscussionContributors(discussionId, Meteor.user().username);                                         // 53
      },                                                                                                            // 55
      'comments.delete': function commentsDelete(commentId) {                                                       // 56
        check(commentId, String);                                                                                   // 57
                                                                                                                    //
        if (!this.userId || !Comments.findOne({ _id: commentId })) {                                                // 59
          throw new Meteor.Error('not-authorized');                                                                 // 61
        }                                                                                                           // 62
                                                                                                                    //
        if (Comments.findOne({ _id: commentId }).username !== Meteor.user().username && !Roles.userIsInRole(this.userId, 'admin') && !Roles.userIsInRole(this.userId, 'moderator')) {
          throw new Meteor.Error('not-authorized');                                                                 // 67
        }                                                                                                           // 68
                                                                                                                    //
        Comments.remove({ _id: commentId });                                                                        // 70
      },                                                                                                            // 71
      'comments.edit': function commentsEdit(commentId, commentText) {                                              // 72
        check(commentId, String);                                                                                   // 73
        check(commentText, String);                                                                                 // 74
                                                                                                                    //
        if (!this.userId || !Comments.findOne({ _id: commentId })) {                                                // 76
          throw new Meteor.Error('not-authorized');                                                                 // 78
        }                                                                                                           // 79
                                                                                                                    //
        if (Comments.findOne({ _id: commentId }).username !== Meteor.user().username && !Roles.userIsInRole(this.userId, 'admin') && !Roles.userIsInRole(this.userId, 'moderator')) {
          throw new Meteor.Error('not-authorized');                                                                 // 84
        }                                                                                                           // 85
                                                                                                                    //
        Comments.update({ _id: commentId }, { $set: { body: commentText } });                                       // 87
      }                                                                                                             // 89
    });                                                                                                             // 34
  })();                                                                                                             // 13
}                                                                                                                   // 91
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"configs.js":["meteor/mongo","meteor/check","meteor/meteor","./builds.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/configs.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Configs:function(){return Configs}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Builds;module.import('./builds.js',{"Builds":function(v){Builds=v}});
                                                                                                                    // 2
                                                                                                                    // 3
                                                                                                                    //
var Configs = new Mongo.Collection('configs');                                                                      // 5
                                                                                                                    // 6
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 8
  Meteor.publish('configs', function () {                                                                           // 9
    if (Roles.userIsInRole(this.userId, 'admin')) {                                                                 // 10
      return Configs.find();                                                                                        // 11
    } else {                                                                                                        // 12
      return Configs.find({ hide: { $ne: true }, $or: [{ owner: this.userId }, { 'public': true }] });              // 13
    }                                                                                                               // 14
  });                                                                                                               // 15
}                                                                                                                   // 16
                                                                                                                    //
Meteor.methods({                                                                                                    // 18
  'configs.makePublic': function configsMakePublic(configId) {                                                      // 19
    check(configId, String);                                                                                        // 20
                                                                                                                    //
    if (!this.userId || Configs.findOne({ _id: configId }).owner !== this.userId) {                                 // 22
      throw new Meteor.Error('not-authorized');                                                                     // 23
    }                                                                                                               // 24
                                                                                                                    //
    Configs.update({ _id: configId }, { $set: { 'public': true } });                                                // 26
  },                                                                                                                // 27
  'configs.makePrivate': function configsMakePrivate(configId) {                                                    // 29
    check(configId, String);                                                                                        // 30
                                                                                                                    //
    if (!this.userId || Configs.findOne({ _id: configId }).owner !== this.userId) {                                 // 32
      throw new Meteor.Error('not-authorized');                                                                     // 33
    }                                                                                                               // 34
                                                                                                                    //
    Configs.update({ _id: configId }, { $set: { 'public': false } });                                               // 36
  },                                                                                                                // 37
  'configs.create': function configsCreate(config, cleanName, fullName, screenshotUrl, description) {               // 39
    check(fullName, String);                                                                                        // 40
    check(screenshotUrl, String);                                                                                   // 41
    check(description, String);                                                                                     // 42
    check(cleanName, String);                                                                                       // 43
                                                                                                                    //
    if (!this.userId) {                                                                                             // 45
      throw new Meteor.Error('not-authorized');                                                                     // 46
    }                                                                                                               // 47
                                                                                                                    //
    Roles.addUsersToRoles(this.userId, 'createdConfig');                                                            // 49
                                                                                                                    //
    Configs.insert({                                                                                                // 51
      config: config,                                                                                               // 52
      name: cleanName,                                                                                              // 53
      fullName: fullName,                                                                                           // 54
      description: description,                                                                                     // 55
      screenshot: screenshotUrl,                                                                                    // 56
      createdAt: new Date(),                                                                                        // 57
      editedAt: new Date(),                                                                                         // 58
      'public': false,                                                                                              // 59
      owner: this.userId,                                                                                           // 60
      username: Meteor.user().username,                                                                             // 61
      upvotes: {},                                                                                                  // 62
      numVotes: 0                                                                                                   // 63
    });                                                                                                             // 51
  },                                                                                                                // 65
  'configs.edit': function configsEdit(configId, config, cleanName, fullName, screenshotUrl, description) {         // 67
    check(configId, String);                                                                                        // 68
    check(fullName, String);                                                                                        // 69
    check(screenshotUrl, String);                                                                                   // 70
    check(description, String);                                                                                     // 71
    check(cleanName, String);                                                                                       // 72
                                                                                                                    //
    if (!this.userId) {                                                                                             // 74
      throw new Meteor.Error('not-authorized');                                                                     // 75
    }                                                                                                               // 76
                                                                                                                    //
    if (this.userId !== config.owner && !Roles.userIsInRole(this.userId, 'admin')) {                                // 78
      throw new Meteor.Error('not-authorized');                                                                     // 79
    }                                                                                                               // 80
                                                                                                                    //
    if (!Configs.findOne({ _id: configId })) {                                                                      // 82
      throw new Meteor.Error('not-found');                                                                          // 83
    }                                                                                                               // 84
                                                                                                                    //
    Configs.update({ _id: configId }, { $set: {                                                                     // 86
        config: config,                                                                                             // 87
        name: cleanName,                                                                                            // 88
        fullName: fullName,                                                                                         // 89
        description: description,                                                                                   // 90
        screenshot: screenshotUrl,                                                                                  // 91
        editedAt: new Date()                                                                                        // 92
      } });                                                                                                         // 86
  },                                                                                                                // 94
  'configs.delete': function configsDelete(configId) {                                                              // 96
    check(configId, String);                                                                                        // 97
                                                                                                                    //
    if (!this.userId) {                                                                                             // 99
      throw new Meteor.Error('not-authorized');                                                                     // 100
    }                                                                                                               // 101
                                                                                                                    //
    if (this.userId !== Configs.findOne({ _id: configId }).owner && !Roles.userIsInRole(this.userId, 'admin')) {    // 103
      throw new Meteor.Error('not-authorized');                                                                     // 104
    }                                                                                                               // 105
                                                                                                                    //
    Configs.remove({ _id: configId });                                                                              // 107
    Builds.remove({ configId: configId });                                                                          // 108
  },                                                                                                                // 109
  'configs.upvote': function configsUpvote(configId) {                                                              // 111
    check(configId, String);                                                                                        // 112
                                                                                                                    //
    if (!this.userId) {                                                                                             // 114
      throw new Meteor.Error('not-authorized');                                                                     // 115
    }                                                                                                               // 116
                                                                                                                    //
    var currentUpvotes = Configs.findOne({ _id: configId }).upvotes;                                                // 118
    currentUpvotes[this.userId] = true;                                                                             // 119
    Configs.update({ _id: configId }, { $set: { upvotes: currentUpvotes } });                                       // 120
                                                                                                                    //
    var numVotes = 0;                                                                                               // 122
    for (var username in currentUpvotes) {                                                                          // 123
      if (currentUpvotes[username]) {                                                                               // 124
        numVotes += 1;                                                                                              // 125
      }                                                                                                             // 126
    }                                                                                                               // 127
                                                                                                                    //
    Configs.update({ _id: configId }, { $set: { numVotes: numVotes } });                                            // 129
  },                                                                                                                // 130
  'configs.unVote': function configsUnVote(configId) {                                                              // 132
    check(configId, String);                                                                                        // 133
                                                                                                                    //
    if (!this.userId) {                                                                                             // 135
      throw new Meteor.Error('not-authorized');                                                                     // 136
    }                                                                                                               // 137
                                                                                                                    //
    var currentUpvotes = Configs.findOne({ _id: configId }).upvotes;                                                // 139
    currentUpvotes[this.userId] = false;                                                                            // 140
    Configs.update({ _id: configId }, { $set: { upvotes: currentUpvotes } });                                       // 141
                                                                                                                    //
    var numVotes = 0;                                                                                               // 143
    for (var username in currentUpvotes) {                                                                          // 144
      if (currentUpvotes[username]) {                                                                               // 145
        numVotes += 1;                                                                                              // 146
      }                                                                                                             // 147
    }                                                                                                               // 148
                                                                                                                    //
    Configs.update({ _id: configId }, { $set: { numVotes: numVotes } });                                            // 150
  }                                                                                                                 // 151
});                                                                                                                 // 18
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"content.js":["meteor/mongo","meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/content.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Content:function(){return Content}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                    // 2
                                                                                                                    //
var Content = new Mongo.Collection('content');                                                                      // 4
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 6
  Meteor.publish('content', function () {                                                                           // 7
    return Content.find();                                                                                          // 8
  });                                                                                                               // 9
}                                                                                                                   // 10
                                                                                                                    //
Meteor.methods({                                                                                                    // 12
  'content.change': function contentChange(contentName, contentText) {                                              // 13
    check(contentName, String);                                                                                     // 14
    if (!this.userId || !Roles.userIsInRole(this.userId, 'admin')) {                                                // 15
      throw new Meteor.Error('not-authorized');                                                                     // 16
    }                                                                                                               // 17
    if (!Content.findOne({ name: contentName })) {                                                                  // 18
      throw new Meteor.Error('no-such-content');                                                                    // 19
    }                                                                                                               // 20
    Content.update({ name: contentName }, { $set: { text: contentText } });                                         // 21
  }                                                                                                                 // 22
});                                                                                                                 // 12
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"discussions.js":["meteor/mongo","meteor/check","./categories.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/discussions.js                                                                                       //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Discussions:function(){return Discussions}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Categories;module.import('./categories.js',{"Categories":function(v){Categories=v}});
                                                                                                                    // 2
                                                                                                                    //
                                                                                                                    // 4
                                                                                                                    //
var Discussions = new Mongo.Collection('discussions');                                                              // 6
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 8
  Meteor.publish('discussions', function () {                                                                       // 9
    return Discussions.find();                                                                                      // 10
  });                                                                                                               // 11
}                                                                                                                   // 12
                                                                                                                    //
Meteor.methods({                                                                                                    // 14
  'discussions.add': function discussionsAdd(discussionName, discussionText, discussionCategory) {                  // 15
    check(discussionName, String);                                                                                  // 16
    check(discussionText, String);                                                                                  // 17
    check(discussionCategory, String);                                                                              // 18
                                                                                                                    //
    if (!this.userId) {                                                                                             // 20
      throw new Meteor.Error('not-authorized');                                                                     // 21
    }                                                                                                               // 22
                                                                                                                    //
    if (discussionName.length < 0) {                                                                                // 24
      throw new Meteor.Error('title-required');                                                                     // 25
    }                                                                                                               // 26
                                                                                                                    //
    if (discussionText.length < 0) {                                                                                // 28
      throw new Meteor.Error('text-required');                                                                      // 29
    }                                                                                                               // 30
                                                                                                                    //
    if (!Categories.findOne({ name: discussionCategory })) {                                                        // 32
      throw new Meteor.Error('category-not-found');                                                                 // 33
    }                                                                                                               // 34
                                                                                                                    //
    if (Categories.findOne({ name: discussionCategory }).restricted && !Roles.userIsInRole(this.userId, 'admin')) {
      throw new Meteor.Error('not-authorized');                                                                     // 37
    }                                                                                                               // 38
                                                                                                                    //
    Discussions.insert({                                                                                            // 40
      username: Meteor.user().username,                                                                             // 41
      category: Categories.findOne({ name: discussionCategory })._id,                                               // 42
      name: discussionName,                                                                                         // 43
      body: discussionText,                                                                                         // 44
      createdAt: new Date(),                                                                                        // 45
      owner: this.userId                                                                                            // 46
    });                                                                                                             // 40
  },                                                                                                                // 48
  'discussions.delete': function discussionsDelete(discussionId) {                                                  // 49
    check(discussionId, String);                                                                                    // 50
                                                                                                                    //
    if (!this.userId || !Discussions.findOne({ _id: discussionId })) {                                              // 52
      throw new Meteor.Error('not-authorized');                                                                     // 54
    }                                                                                                               // 55
                                                                                                                    //
    if (Discussions.findOne({ _id: discussionId }).owner !== this.userId && !Roles.userIsInRole(this.userId, 'admin') && !Roles.userIsInRole(this.userId, 'moderator')) {
      throw new Meteor.Error('not-authorized');                                                                     // 60
    }                                                                                                               // 61
                                                                                                                    //
    Discussions.remove({ _id: discussionId });                                                                      // 63
  },                                                                                                                // 64
  'discussions.edit': function discussionsEdit(discussionId, discussionText) {                                      // 65
    check(discussionId, String);                                                                                    // 66
    check(discussionText, String);                                                                                  // 67
                                                                                                                    //
    if (!this.userId || !Discussions.findOne({ _id: discussionId })) {                                              // 69
      throw new Meteor.Error('not-authorized');                                                                     // 71
    }                                                                                                               // 72
                                                                                                                    //
    if (Discussions.findOne({ _id: discussionId }).owner !== this.userId && !Roles.userIsInRole(this.userId, 'admin') && !Roles.userIsInRole(this.userId, 'moderator')) {
      throw new Meteor.Error('not-authorized');                                                                     // 77
    }                                                                                                               // 78
                                                                                                                    //
    Discussions.update({ _id: discussionId }, { $set: { body: discussionText } });                                  // 80
  }                                                                                                                 // 82
});                                                                                                                 // 14
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"docs.js":["meteor/mongo","meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/docs.js                                                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Docs:function(){return Docs}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                    // 2
                                                                                                                    //
var Docs = new Mongo.Collection('docs');                                                                            // 4
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 6
  Meteor.publish('docs', function () {                                                                              // 7
    return Docs.find();                                                                                             // 8
  });                                                                                                               // 9
}                                                                                                                   // 10
                                                                                                                    //
Meteor.methods({                                                                                                    // 12
  'docs.add': function docsAdd(docsEntryName, docsEntryText) {                                                      // 13
    check(docsEntryName, String);                                                                                   // 14
    check(docsEntryText, String);                                                                                   // 15
                                                                                                                    //
    var cleanName = docsEntryName.replace(/[^a-z0-9]/gi, '-').toLowerCase();                                        // 17
                                                                                                                    //
    if (!this.userId) {                                                                                             // 19
      throw new Meteor.Error('not-authorized');                                                                     // 20
    }                                                                                                               // 21
                                                                                                                    //
    if (Docs.findOne({ cleanName: cleanName })) {                                                                   // 23
      throw new Meteor.Error('already-exists');                                                                     // 24
    }                                                                                                               // 25
                                                                                                                    //
    if (docsEntryName.length < 0) {                                                                                 // 27
      throw new Meteor.Error('title-required');                                                                     // 28
    }                                                                                                               // 29
                                                                                                                    //
    if (docsEntryText.length < 0) {                                                                                 // 31
      throw new Meteor.Error('text-required');                                                                      // 32
    }                                                                                                               // 33
                                                                                                                    //
    Docs.insert({                                                                                                   // 35
      username: Meteor.user().username,                                                                             // 36
      name: docsEntryName,                                                                                          // 37
      cleanName: cleanName,                                                                                         // 38
      body: docsEntryText,                                                                                          // 39
      createdAt: new Date(),                                                                                        // 40
      owner: this.userId,                                                                                           // 41
      edits: [{ body: docsEntryText,                                                                                // 42
        user: this.userId,                                                                                          // 43
        username: Meteor.user().username,                                                                           // 44
        createdAt: new Date() }]                                                                                    // 45
    });                                                                                                             // 35
  },                                                                                                                // 47
  'docs.delete': function docsDelete(docsEntryId) {                                                                 // 48
    check(docsEntryId, String);                                                                                     // 49
                                                                                                                    //
    if (!this.userId || !Docs.findOne({ _id: docsEntryId })) {                                                      // 51
      throw new Meteor.Error('not-authorized');                                                                     // 53
    }                                                                                                               // 54
                                                                                                                    //
    if (!Roles.userIsInRole(this.userId, 'admin') && Docs.findOne({ _id: docsEntryId }).owner !== this.userId) {    // 56
      throw new Meteor.Error('not-authorized');                                                                     // 58
    }                                                                                                               // 59
                                                                                                                    //
    Docs.remove({ _id: docsEntryId });                                                                              // 61
  },                                                                                                                // 62
  'docs.edit': function docsEdit(docsEntryId, docsEntryText) {                                                      // 63
    check(docsEntryId, String);                                                                                     // 64
    check(docsEntryText, String);                                                                                   // 65
                                                                                                                    //
    if (!this.userId || !Docs.findOne({ _id: docsEntryId })) {                                                      // 67
      throw new Meteor.Error('not-authorized');                                                                     // 69
    }                                                                                                               // 70
                                                                                                                    //
    // if (!Roles.userIsInRole(this.userId, 'admin') &&                                                             //
    //     Docs.findOne({_id: docsEntryId}).owner !== this.userId) {                                                //
    //   throw new Meteor.Error('not-authorized');                                                                  //
    // }                                                                                                            //
                                                                                                                    //
    Docs.update({ _id: docsEntryId }, { $set: { body: docsEntryText } });                                           // 77
    Docs.update({ _id: docsEntryId }, { $push: { edits: { body: docsEntryText,                                      // 79
          user: this.userId,                                                                                        // 81
          username: Meteor.user().username,                                                                         // 82
          createdAt: new Date() } } });                                                                             // 83
  }                                                                                                                 // 84
});                                                                                                                 // 12
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"downloads.js":["meteor/mongo","meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/downloads.js                                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Downloads:function(){return Downloads}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                    // 2
                                                                                                                    //
var Downloads = new Mongo.Collection('downloads');                                                                  // 4
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 6
  Meteor.publish('downloads', function () {                                                                         // 7
    return Downloads.find();                                                                                        // 8
  });                                                                                                               // 9
}                                                                                                                   // 10
                                                                                                                    //
Meteor.methods({                                                                                                    // 12
  'downloads.insert': function downloadsInsert(name, edition, channel, version, type) {                             // 13
    if (!name) {                                                                                                    // 14
      throw new Meteor.Error('name-required');                                                                      // 15
    }                                                                                                               // 16
    Downloads.insert({                                                                                              // 17
      name: name,                                                                                                   // 18
      edition: edition,                                                                                             // 19
      channel: channel,                                                                                             // 20
      version: version,                                                                                             // 21
      type: type,                                                                                                   // 22
      createdAt: new Date()                                                                                         // 23
    });                                                                                                             // 17
  }                                                                                                                 // 25
});                                                                                                                 // 12
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"packages.js":["meteor/mongo","meteor/check","meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/packages.js                                                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Packages:function(){return Packages}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                    // 2
                                                                                                                    // 3
                                                                                                                    //
var Packages = new Mongo.Collection('packages');                                                                    // 5
                                                                                                                    //
function startQueuedPackage() {                                                                                     // 7
  var pkg = Packages.findOne({ queued: true }, { sort: { queuedTime: 1 } });                                        // 8
                                                                                                                    //
  HTTP.del('http://45.55.247.46:8000/repo');                                                                        // 10
  HTTP.put('http://45.55.247.46:8000/repo', {                                                                       // 11
    params: {                                                                                                       // 12
      'package_name': pkg.packageName,                                                                              // 13
      'repo_name': pkg.repoName,                                                                                    // 14
      'repo_endpoint': pkg.repoEndpoint                                                                             // 15
    }                                                                                                               // 12
  }, function (error, response) {                                                                                   // 11
    if (error) {                                                                                                    // 18
      // console.log(error);                                                                                        //
    } else {                                                                                                        // 20
        Packages.update({ _id: pkg._id }, { $set: { running: true, queued: false } });                              // 21
        // console.log(response);                                                                                   //
      }                                                                                                             // 23
  });                                                                                                               // 24
}                                                                                                                   // 25
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 27
  Meteor.publish('packages', function () {                                                                          // 28
    return Packages.find();                                                                                         // 29
  });                                                                                                               // 30
                                                                                                                    //
  Meteor.setInterval(function checkPackageQueue() {                                                                 // 32
    if (!Packages.findOne({ running: true })) {                                                                     // 33
      if (Packages.find({ queued: true }).fetch().length) {                                                         // 34
        startQueuedPackage();                                                                                       // 35
      }                                                                                                             // 36
    } else {                                                                                                        // 37
      HTTP.get('http://45.55.247.46:8000/repo', {}, function (error, response) {                                    // 38
        if (error) {                                                                                                // 39
          // console.log(error);                                                                                    //
        } else {                                                                                                    // 41
            var runningPackage = Packages.findOne({ running: true });                                               // 42
            // console.log(response);                                                                               //
            var data = response.data;                                                                               // 44
            if (data.status === 'success') {                                                                        // 45
              Packages.update({ running: true }, { $set: {                                                          // 46
                  running: false,                                                                                   // 47
                  queued: false,                                                                                    // 48
                  completed: true,                                                                                  // 49
                  failed: false,                                                                                    // 50
                  log: 'http://192.241.147.116/' + runningPackage.repoEndpoint + '/' + runningPackage.packageName + '.log'
                } });                                                                                               // 46
            } else if (data.status === 'failure') {                                                                 // 55
              Packages.update({ running: true }, { $set: {                                                          // 56
                  running: false,                                                                                   // 57
                  queued: false,                                                                                    // 58
                  completed: false,                                                                                 // 59
                  failed: true,                                                                                     // 60
                  log: 'http://192.241.147.116/' + runningPackage.repoEndpoint + '/' + runningPackage.packageName + '.log'
                } });                                                                                               // 56
            } else if (data.status === 'not completed') {                                                           // 65
              // console.log('Current package not completed');                                                      //
            }                                                                                                       // 67
          }                                                                                                         // 68
      });                                                                                                           // 69
    }                                                                                                               // 70
  }, 30000); // run every 30 seconds                                                                                // 71
}                                                                                                                   // 72
                                                                                                                    //
Meteor.methods({                                                                                                    // 74
  'packages.add': function packagesAdd(packageName) {                                                               // 75
    check(packageName, String);                                                                                     // 76
                                                                                                                    //
    if (!this.userId) {                                                                                             // 78
      throw new Meteor.Error('not-authorized');                                                                     // 79
    }                                                                                                               // 80
                                                                                                                    //
    if (!packageExists(packageName)) {                                                                              // 82
      throw new Meteor.Error('invalid-package');                                                                    // 83
    }                                                                                                               // 84
                                                                                                                    //
    var packageNum = Packages.find({                                                                                // 86
      packageName: packageName                                                                                      // 87
    }).fetch().length + 1;                                                                                          // 86
                                                                                                                    //
    Packages.insert({                                                                                               // 90
      packageName: packageName,                                                                                     // 91
      initiator: this.userId,                                                                                       // 92
      running: false,                                                                                               // 93
      queued: true,                                                                                                 // 94
      queuedTime: new Date(),                                                                                       // 95
      buildNum: packageNum                                                                                          // 96
    });                                                                                                             // 90
  }                                                                                                                 // 98
});                                                                                                                 // 74
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"posts.js":["meteor/mongo","meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/posts.js                                                                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({Posts:function(){return Posts}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                    // 2
                                                                                                                    //
var Posts = new Mongo.Collection('posts');                                                                          // 4
                                                                                                                    //
if (Meteor.isServer) {                                                                                              // 6
  Meteor.publish('posts', function () {                                                                             // 7
    return Posts.find();                                                                                            // 8
  });                                                                                                               // 9
}                                                                                                                   // 10
                                                                                                                    //
Meteor.methods({                                                                                                    // 12
  'posts.add': function postsAdd(postName, postText) {                                                              // 13
    check(postName, String);                                                                                        // 14
    check(postText, String);                                                                                        // 15
                                                                                                                    //
    if (!this.userId) {                                                                                             // 17
      throw new Meteor.Error('not-authorized');                                                                     // 18
    }                                                                                                               // 19
                                                                                                                    //
    if (!Roles.userIsInRole(this.userId, 'admin')) {                                                                // 21
      throw new Meteor.Error('not-authorized');                                                                     // 22
    }                                                                                                               // 23
                                                                                                                    //
    if (postName.length < 0) {                                                                                      // 25
      throw new Meteor.Error('title-required');                                                                     // 26
    }                                                                                                               // 27
                                                                                                                    //
    if (postText.length < 0) {                                                                                      // 29
      throw new Meteor.Error('text-required');                                                                      // 30
    }                                                                                                               // 31
                                                                                                                    //
    Posts.insert({                                                                                                  // 33
      username: Meteor.user().username,                                                                             // 34
      name: postName,                                                                                               // 35
      cleanName: postName.replace(/[^a-z0-9]/gi, '-').toLowerCase(),                                                // 36
      body: postText,                                                                                               // 37
      createdAt: new Date(),                                                                                        // 38
      owner: this.userId                                                                                            // 39
    });                                                                                                             // 33
  },                                                                                                                // 41
  'posts.delete': function postsDelete(postId) {                                                                    // 42
    check(postId, String);                                                                                          // 43
                                                                                                                    //
    if (!this.userId || !Posts.findOne({ _id: postId }) || Posts.findOne({ _id: postId }).owner !== this.userId) {  // 45
      throw new Meteor.Error('not-authorized');                                                                     // 48
    }                                                                                                               // 49
                                                                                                                    //
    Posts.remove({ _id: postId });                                                                                  // 51
  },                                                                                                                // 52
  'posts.edit': function postsEdit(postId, postText) {                                                              // 53
    check(postId, String);                                                                                          // 54
    check(postText, String);                                                                                        // 55
                                                                                                                    //
    if (!this.userId || !Posts.findOne({ _id: postId }) || Posts.findOne({ _id: postId }).owner !== this.userId) {  // 57
      throw new Meteor.Error('not-authorized');                                                                     // 60
    }                                                                                                               // 61
                                                                                                                    //
    Posts.update({ _id: postId }, { $set: { body: postText } });                                                    // 63
  }                                                                                                                 // 65
});                                                                                                                 // 12
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"stripe.js":["meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/stripe.js                                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var check;module.import('meteor/check',{"check":function(v){check=v}});                                             // 1
                                                                                                                    //
var Stripe = StripeAPI(Meteor.settings['private'].stripe);                                                          // 3
                                                                                                                    //
Meteor.methods({                                                                                                    // 5
  processPayment: function processPayment(charge) {                                                                 // 6
    check(charge, {                                                                                                 // 7
      amount: Number,                                                                                               // 8
      currency: String,                                                                                             // 9
      source: String,                                                                                               // 10
      description: String,                                                                                          // 11
      receipt_email: String                                                                                         // 12
    });                                                                                                             // 7
                                                                                                                    //
    var handleCharge = Meteor.wrapAsync(Stripe.charges.create, Stripe.charges);                                     // 15
    return handleCharge(charge);                                                                                    // 16
  }                                                                                                                 // 17
});                                                                                                                 // 5
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":["meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/users.js                                                                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});                                         // 1
                                                                                                                    //
Meteor.publish('users', function () {                                                                               // 3
  if (Roles.userIsInRole(this.userId, 'admin')) {                                                                   // 4
    return Meteor.users.find({}, { fields: { 'emails.address': true,                                                // 5
        'username': true,                                                                                           // 6
        'roles': true } });                                                                                         // 7
  } else {                                                                                                          // 8
    return null;                                                                                                    // 9
  }                                                                                                                 // 10
});                                                                                                                 // 11
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"vanillaimports.js":["meteor/mongo",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// imports/api/vanillaimports.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({ImportedUsers:function(){return ImportedUsers},ImportedCategories:function(){return ImportedCategories},ImportedDiscussions:function(){return ImportedDiscussions},ImportedComments:function(){return ImportedComments}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                                                    //
var ImportedUsers = new Mongo.Collection('imported_users');                                                         // 3
var ImportedCategories = new Mongo.Collection('imported_categories');                                               // 4
var ImportedDiscussions = new Mongo.Collection('imported_discussions');                                             // 5
var ImportedComments = new Mongo.Collection('imported_comments');                                                   // 6
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["meteor/meteor","../imports/api/content.js","../imports/api/configs.js","../imports/api/builds.js","../imports/api/packages.js","../imports/api/users.js","../imports/api/posts.js","../imports/api/docs.js","../imports/api/stripe.js","../imports/api/downloads.js","../lib/runonce.js","../imports/api/vanillaimports.js","../imports/api/categories.js","../imports/api/discussions.js","../imports/api/comments.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});module.import('../imports/api/content.js');module.import('../imports/api/configs.js');module.import('../imports/api/builds.js');module.import('../imports/api/packages.js');module.import('../imports/api/users.js');module.import('../imports/api/posts.js');module.import('../imports/api/docs.js');module.import('../imports/api/stripe.js');module.import('../imports/api/downloads.js');var runOnce;module.import('../lib/runonce.js',{"runOnce":function(v){runOnce=v}});var ImportedUsers,ImportedCategories,ImportedDiscussions,ImportedComments;module.import('../imports/api/vanillaimports.js',{"ImportedUsers":function(v){ImportedUsers=v},"ImportedCategories":function(v){ImportedCategories=v},"ImportedDiscussions":function(v){ImportedDiscussions=v},"ImportedComments":function(v){ImportedComments=v}});var Categories,ParentCategories;module.import('../imports/api/categories.js',{"Categories":function(v){Categories=v},"ParentCategories":function(v){ParentCategories=v}});var Discussions;module.import('../imports/api/discussions.js',{"Discussions":function(v){Discussions=v}});var Comments;module.import('../imports/api/comments.js',{"Comments":function(v){Comments=v}});var Posts;module.import('../imports/api/posts.js',{"Posts":function(v){Posts=v}});
                                                                                                                    //
                                                                                                                    // 3
                                                                                                                    // 4
                                                                                                                    // 5
                                                                                                                    // 6
                                                                                                                    // 7
                                                                                                                    // 8
                                                                                                                    // 9
                                                                                                                    // 10
                                                                                                                    // 11
                                                                                                                    //
                                                                                                                    // 13
                                                                                                                    // 14
                                                                                                                    //
                                                                                                                    // 19
                                                                                                                    // 20
                                                                                                                    // 21
                                                                                                                    // 22
                                                                                                                    //
Meteor.startup(function () {                                                                                        // 24
  // Delete                                                                                                         //
  // SSLProxy({                                                                                                     //
  //   port: 6000,                                                                                                  //
  //   ssl: {                                                                                                       //
  //     key: Assets.getText("key.pem"),                                                                            //
  //     cert: Assets.getText("cert.pem")                                                                           //
  //   }                                                                                                            //
  // });                                                                                                            //
                                                                                                                    //
  UploadServer.init({                                                                                               // 34
    tmpDir: process.env.PWD + '/.uploads/tmp/',                                                                     // 35
    uploadDir: process.env.PWD + '/.uploads/',                                                                      // 36
    maxFileSize: 100000000, // 100 mb                                                                               // 37
    checkCreateDirectories: true, //create the directories for you                                                  // 38
    getDirectory: function getDirectory(fileInfo, formData) {                                                       // 39
      return formData.username + '/';                                                                               // 40
    }                                                                                                               // 41
  });                                                                                                               // 34
                                                                                                                    //
  Accounts.emailTemplates.siteName = 'Apricity OS';                                                                 // 44
  Accounts.emailTemplates.from = 'Apricity OS Accounts <postmaster@apricityos.com>';                                // 45
                                                                                                                    //
  Accounts.emailTemplates.enrollAccount.subject = function (user) {                                                 // 47
    return 'Apricity OS: Account Verification';                                                                     // 48
  };                                                                                                                // 49
  Accounts.emailTemplates.enrollAccount.text = function (user, url) {                                               // 50
    return 'Hi ' + user.username + '!\n\n' + 'Apricity OS has a brand new site, and we\'ve automatically generated ' + 'an account for you based on the one you had on the old forum. ' + 'You\'ll be able to post things on the new forum, as well as contribute ' + 'to the new wiki and participate in IRC discussions. You\'ll ' + 'also be able to create Freezedry configurations and build them online.' + '\n\nClick the link below to verify your account and set your password:' + '\n' + url;
  };                                                                                                                // 59
                                                                                                                    //
  Accounts.emailTemplates.verifyEmail.subject = function (user) {                                                   // 61
    return 'Apricity OS: Account Verification';                                                                     // 62
  };                                                                                                                // 63
  Accounts.emailTemplates.verifyEmail.text = function (user, url) {                                                 // 64
    return 'Hi ' + user.username + '!\n\n' + 'Thanks for making an account at the Apricity OS website! ' + '\n\nYou\'ll be able to post things on the new forum, as well as contribute ' + 'to the new wiki and participate in IRC discussions. You\'ll ' + 'also be able to create Freezedry configurations and build them online.' + '\n\nClick the link below to verify your account:' + '\n' + url;
  };                                                                                                                // 72
                                                                                                                    //
  if (!Meteor.users.findOne({ username: 'admin' })) {                                                               // 74
    runOnce(function () {                                                                                           // 75
      console.log('Creating admin');                                                                                // 76
      Accounts.createUser({                                                                                         // 77
        username: 'admin',                                                                                          // 78
        email: 'agajews@gmail.com'                                                                                  // 79
      });                                                                                                           // 77
      var adminId = Meteor.users.findOne({ username: 'admin' })._id;                                                // 81
      Roles.addUsersToRoles(adminId, 'admin');                                                                      // 82
      Accounts.sendEnrollmentEmail(adminId);                                                                        // 83
    }, 'createAdmin');                                                                                              // 84
  }                                                                                                                 // 85
                                                                                                                    //
  if (ImportedUsers.find().fetch().length > 0) {                                                                    // 87
    runOnce(function () {                                                                                           // 88
      console.log('Importing users');                                                                               // 89
      _.each(ImportedUsers.find().fetch(), function (user) {                                                        // 90
        if (!Meteor.users.findOne({ username: user.username })) {                                                   // 91
          Accounts.createUser({                                                                                     // 92
            username: user.username,                                                                                // 93
            email: user.email                                                                                       // 94
          });                                                                                                       // 92
          var userId = Meteor.users.findOne({ username: user.username })._id;                                       // 96
          Roles.addUsersToRoles(userId, 'user');                                                                    // 97
          // ENABLE                                                                                                 //
          // Accounts.sendEnrollmentEmail(userId);                                                                  //
        }                                                                                                           // 100
      });                                                                                                           // 101
    }, 'importUsers');                                                                                              // 102
  }                                                                                                                 // 103
                                                                                                                    //
  if (ImportedCategories.find().fetch().length > 0) {                                                               // 105
    runOnce(function () {                                                                                           // 106
      console.log('Importing categories');                                                                          // 107
      _.each(ImportedCategories.find().fetch(), function (category) {                                               // 108
        if (category.parentName !== 'Root') {                                                                       // 109
          ParentCategories.upsert({ name: category.parentName }, { name: category.parentName });                    // 110
          var restricted = false;                                                                                   // 112
          if (category.restricted) {                                                                                // 113
            restricted = true;                                                                                      // 114
          }                                                                                                         // 115
          Categories.insert({                                                                                       // 116
            name: category.name,                                                                                    // 117
            description: category.description,                                                                      // 118
            parent: ParentCategories.findOne({ name: category.parentName })._id,                                    // 119
            restricted: restricted                                                                                  // 120
          }, function (error, _id) {                                                                                // 116
            ImportedCategories.update({ categoryId: category.categoryId }, { $set: { mongoId: _id } });             // 122
          });                                                                                                       // 124
        }                                                                                                           // 125
      });                                                                                                           // 126
    }, 'importCategories');                                                                                         // 127
  }                                                                                                                 // 128
                                                                                                                    //
  if (ImportedDiscussions.find().fetch().length > 0 && ImportedUsers.find().fetch().length > 0 && ImportedCategories.find().fetch().length > 0) {
    runOnce(function () {                                                                                           // 133
      console.log('Importing discussions');                                                                         // 134
      _.each(ImportedDiscussions.find().fetch(), function (discussion) {                                            // 135
        Discussions.insert({                                                                                        // 136
          name: discussion.name,                                                                                    // 137
          body: discussion.body,                                                                                    // 138
          category: ImportedCategories.findOne({ name: discussion.category }).mongoId,                              // 139
          username: discussion.username,                                                                            // 140
          owner: Meteor.users.findOne({ username: discussion.username })._id,                                       // 141
          createdAt: new Date(discussion.createdAt)                                                                 // 142
        }, function (error, _id) {                                                                                  // 136
          ImportedDiscussions.update({ discussionId: discussion.discussionId }, { $set: { mongoId: _id } });        // 144
        });                                                                                                         // 146
      });                                                                                                           // 147
    }, 'importDiscussions');                                                                                        // 148
  }                                                                                                                 // 149
                                                                                                                    //
  if (ImportedComments.find().fetch().length > 0 && ImportedUsers.find().fetch().length > 0 && ImportedDiscussions.find({ mongoId: { $ne: false } }).fetch().length > 0 && ImportedCategories.find().fetch().length > 0) {
    runOnce(function () {                                                                                           // 155
      console.log('Importing comments');                                                                            // 156
      _.each(ImportedComments.find().fetch(), function (comment) {                                                  // 157
        if (ImportedDiscussions.findOne({ discussionId: comment.discussionId })) {                                  // 158
          Comments.insert({                                                                                         // 159
            body: comment.body,                                                                                     // 160
            username: comment.username,                                                                             // 161
            owner: Meteor.users.findOne({ username: comment.username })._id,                                        // 162
            discussion: ImportedDiscussions.findOne({ discussionId: comment.discussionId }).mongoId,                // 163
            createdAt: new Date(comment.createdAt)                                                                  // 164
          });                                                                                                       // 159
        } else {                                                                                                    // 166
          console.log('Comment discussion not found');                                                              // 167
        }                                                                                                           // 168
      });                                                                                                           // 169
    }, 'importComments');                                                                                           // 170
                                                                                                                    //
    if (Posts.find({ cleanName: { $ne: true } }).fetch().length > 0) {                                              // 172
      runOnce(function () {                                                                                         // 173
        console.log('Cleaning imported post names');                                                                // 174
        _.each(Posts.find({ cleanName: { $ne: true } }).fetch(), function (post) {                                  // 175
          Posts.update({ _id: post._id }, { $set: { cleanName: post.name.replace(/[^a-z0-9]/gi, '-').toLowerCase() } });
        });                                                                                                         // 177
      });                                                                                                           // 178
    }                                                                                                               // 179
  }                                                                                                                 // 180
});                                                                                                                 // 181
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/accounts.js");
require("./lib/routes.js");
require("./lib/runonce.js");
require("./lib/underscore.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
