(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var FlowRouter = Package['kadira:flow-router'].FlowRouter;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/tomwasd_flow-router-autoscroll/packages/tomwasd_flow-rou //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tomwasd:flow-router-autoscroll'] = {};

})();
